</div>
<footer>
    <p class="copyright">
        &copy;<?php echo date("Y"); ?> Add your name here
    </p>
</footer>
</body>
</html>