<?php 
//add your php code here to receive user inputted height and weight
//add your php code to calculate BMI
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">	
    <title>BMI Calculation</title>
    <link rel="stylesheet" href="bmi_style.css">
</head>
<body>
	<main>
		<h1>Body Mass Index Calculation Application</h1>
		     
		<div id='heightInput'>Your height (in inches): 
            <?php //add your php code here to display user's height input ?> 
        </div>
	
		<div id='weightInput'>Your weight (in pounds):  
            <?php //add your php code here to display user's weight input ?> 
        </div>
		
		<div id='bmi'> Your BMI:  
            <?php //add your php code here to display BMI (with one decimal place) ?> 
        </div>
		
	</main>
	 
</body>
</html>
